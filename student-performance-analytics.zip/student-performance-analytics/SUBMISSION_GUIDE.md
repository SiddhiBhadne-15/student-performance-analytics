# Submission Guide (do these in order)

**Before you start:** open `README.md` and replace `<YOUR NAME>` and the GitHub link placeholder. Run `python main.py` once, take 2–3 screenshots of the output, put them in a `screenshots/` folder.

## Push to GitHub
1. Sign in at github.com -> **New repository**.
2. Name: `student-performance-analytics`. Set **Public** (or as your trainer says). Do not tick "Add README" (you already have one).
3. In a terminal inside the project folder:
```bash
git init
git add .
git commit -m "Student Performance Analytics System"
git branch -M main
git remote add origin https://github.com/<your-username>/student-performance-analytics.git
git push -u origin main
```
(Or on the repo page use **Add file -> Upload files** and drag all files in.)
4. Refresh the repo page and confirm you see: `main.py`, `functions.py`, `students.csv`, `README.md`.
5. Copy the repo URL and paste it into the README (section 10), then:
```bash
git add README.md && git commit -m "Add repo link" && git push
```
6. Submit the repo URL in the **EWB Google Form**.

## Final checklist
- [ ] Project runs without errors
- [ ] students.csv included (20 records)
- [ ] NumPy + Pandas used; functions + loops used
- [ ] README.md has all 10 documentation sections
- [ ] Screenshots added
- [ ] Repo is public, link submitted in Google Form
- [ ] Final repo checked

## Be ready to explain (assessment is on understanding)
- Why `np.mean(..., axis=1)` works row-wise
- Your grading rule and pass condition
- What `groupby` and `np.where` do
- Change the dataset yourself (add a student) and re-run
